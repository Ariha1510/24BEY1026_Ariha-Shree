const Doctor = require("./models/Doctor");
const Appointment = require("./models/Appointment");
const Department = require("./models/Department");
const express=require("express");
require("./db");

const app = express();

app.use(express.json());

app.get("/", (req, res) => {
    res.send("Hospital Management API Running");
});

const Patient = require("./models/Patient");

app.post("/patients", async (req, res) => {
    try {
        const patient = await Patient.create(req.body);
        res.json(patient);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.get("/patients", async (req, res) => {
    try {
        const patients = await Patient.find();
        res.json(patients);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.put("/patients/:id", async (req, res) => {
    try {
        const patient = await Patient.findByIdAndUpdate(
            req.params.id,
            req.body,
            { new: true }
        );

        res.json(patient);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.delete("/patients/:id", async (req, res) => {
    try {
        await Patient.findByIdAndDelete(req.params.id);
        res.send("Patient Deleted");
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});
// CREATE Department
app.post("/departments", async (req, res) => {
    try {
        const department = await Department.create(req.body);
        res.json(department);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// READ Departments
app.get("/departments", async (req, res) => {
    try {
        const departments = await Department.find();
        res.json(departments);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// UPDATE Department
app.put("/departments/:id", async (req, res) => {
    try {
        const department = await Department.findByIdAndUpdate(
            req.params.id,
            req.body,
            { new: true }
        );

        res.json(department);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// DELETE Department
app.delete("/departments/:id", async (req, res) => {
    try {
        await Department.findByIdAndDelete(req.params.id);
        res.send("Department Deleted");
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});
// CREATE Doctor
app.post("/doctors", async (req, res) => {
    try {
        const doctor = await Doctor.create(req.body);
        res.json(doctor);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// READ Doctors
app.get("/doctors", async (req, res) => {
    try {
        const doctors = await Doctor.find().populate("departmentId");
        res.json(doctors);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// UPDATE Doctor
app.put("/doctors/:id", async (req, res) => {
    try {
        const doctor = await Doctor.findByIdAndUpdate(
            req.params.id,
            req.body,
            { new: true }
        );
        res.json(doctor);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// DELETE Doctor
app.delete("/doctors/:id", async (req, res) => {
    try {
        await Doctor.findByIdAndDelete(req.params.id);
        res.send("Doctor Deleted");
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});
// CREATE Appointment
app.post("/appointments", async (req, res) => {
    try {
        const appointment = await Appointment.create(req.body);
        res.json(appointment);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// READ Appointment
app.get("/appointments", async (req, res) => {
    try {
        const appointments = await Appointment.find()
            .populate("patientId")
            .populate("doctorId");

        res.json(appointments);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// UPDATE Appointment
app.put("/appointments/:id", async (req, res) => {
    try {
        const appointment = await Appointment.findByIdAndUpdate(
            req.params.id,
            req.body,
            { new: true }
        );
        res.json(appointment);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// DELETE Appointment
app.delete("/appointments/:id", async (req, res) => {
    try {
        await Appointment.findByIdAndDelete(req.params.id);
        res.send("Appointment Deleted");
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});
app.listen(3000, () => {
    console.log("Server Running on Port 3000");
});