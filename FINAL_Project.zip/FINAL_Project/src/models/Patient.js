const mongoose = require("mongoose");

const patientSchema = new mongoose.Schema({
    name: { type: String, required: true },
    age: { type: Number, required: true },
    gender: { type: String, required: true },
    phone: { type: String, required: true, unique: true } // 🚀 OPTIMIZATION: Enforces a unique index constraint
});

module.exports = mongoose.model("Patient", patientSchema);