const mongoose = require("mongoose");

const DoctorSchema = new mongoose.Schema({
    name: String,
    specialization: String,
    cabinNo: String,
    departmentId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Department"
    }
});

module.exports = mongoose.model("Doctor", DoctorSchema);