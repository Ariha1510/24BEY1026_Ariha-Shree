const mongoose = require("mongoose");

const appointmentSchema = new mongoose.Schema({
    patientId: { type: mongoose.Schema.Types.ObjectId, ref: "Patient", required: true },
    doctorId: { type: mongoose.Schema.Types.ObjectId, ref: "Doctor", required: true },
    appointmentDate: { type: Date, required: true }
});

// 🚀 OPTIMIZATION: Creates a compound index on Doctor ID and Appointment Date
appointmentSchema.index({ doctorId: 1, appointmentDate: 1 });

module.exports = mongoose.model("Appointment", appointmentSchema);