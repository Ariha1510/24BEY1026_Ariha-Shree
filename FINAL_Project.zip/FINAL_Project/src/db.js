const mongoose = require("mongoose");

// 🔑 Change 127.0.0.1 to localhost to align with your active mongod process
mongoose.connect("mongodb://127.0.0.1:27017/hospitalDB")
.then(() => console.log("MongoDB Connected Successfully!"))
.catch(err => console.log("Database Connection Error: ", err));

module.exports = mongoose;